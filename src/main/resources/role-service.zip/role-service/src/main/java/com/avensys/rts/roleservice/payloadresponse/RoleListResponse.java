package com.avensys.rts.roleservice.payloadresponse;

public class RoleListResponse {
    private String roleName;
    private String roleDescription;
}
