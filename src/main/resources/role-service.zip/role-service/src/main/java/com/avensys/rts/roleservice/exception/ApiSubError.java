package com.avensys.rts.roleservice.exception;

public abstract class ApiSubError {
}
